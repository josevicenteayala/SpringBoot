package com.excel.base;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootExcelApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootExcelApplication.class, args);
	}

}
